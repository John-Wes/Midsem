package status;

// Define an enum for user status codes
public enum StausUser {
    REJECTED, 
    PENDING, 
    PROCESSING, 
    APPROVED;

    // This method returns a status based on the user's input code
    public static StausUser getStatusByCode(String code) {
        switch (code.toUpperCase()) {
            case "ZERO":
                return REJECTED;
            case "ONE":
                return PENDING;
            case "TWO":
                return PROCESSING;
            case "THREE":
                return APPROVED;
            default:
                throw new IllegalArgumentException("Invalid Status Code");
        }
    }
}
