package status;

import java.util.Scanner;

public class Status {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        // Ask the user to input a status code
        System.out.println("Enter the user status code (zero, one, two, three): ");
        String code = in.next(); // Get the status code as input

        // Get the enum value from the string code
        try {
            UserStatus status = UserStatus.getStatusByCode(code);
            StausUser user = new StausUser();
            user.statusDetail(status); // Pass the enum to the statusDetail method
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
